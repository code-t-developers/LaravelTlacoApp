<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ActividadRecreativaController extends Controller
{
    //
}
