<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActividadRecreativa extends Model
{
    //
}
