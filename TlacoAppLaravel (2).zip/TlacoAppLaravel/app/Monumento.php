<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Monumento extends Model
{
    protected $table = "monumento";
}
